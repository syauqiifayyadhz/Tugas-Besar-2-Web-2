# Sistem-Informasi-Inventory-Gudang
Sistem Informasi Inventory Gudang berbasis website dengan Codeigniter 3

### **Sistem Informasi Inventory Gudang Kopi Shop**
Berbasis website dengan menggunakan framework Codeigniter 3

Memiliki 4 User Akses :
1. Admin
2. Petugas Store 
3. Petugas Gudang
4. Petugas Purchasing


Halaman Login
![Login](https://user-images.githubusercontent.com/45915194/154632909-1e05c2c1-8b06-41ec-8216-60d88817d7b7.PNG)


Halaman Beranda (Admin)
![Beranda](https://user-images.githubusercontent.com/45915194/158008535-8b74a5a2-0ec3-4f2f-8308-35cdb1657aa7.PNG)


Halaman Management User (Admin)
![Management User](https://user-images.githubusercontent.com/45915194/158008539-709ca699-d8cd-408b-9b71-f7248718a183.PNG)


Halaman Beranda (Store)
![beranda](https://user-images.githubusercontent.com/45915194/158019974-aa1d0b2a-8298-4a93-80bb-8921e3bce62d.PNG)


Halaman Bahan Baku (Store)
![Bahan Baku](https://user-images.githubusercontent.com/45915194/158019973-b639cee9-adb5-474f-a049-a8966c601126.PNG)


Halaman Permintaan Barang (Store)
![Permintaan Barang](https://user-images.githubusercontent.com/45915194/158019975-fbaa7faa-1bc2-45a8-abda-ca9b98d7e3ba.PNG)


Halaman Beranda (Gudang)
![Beranda](https://user-images.githubusercontent.com/45915194/158020014-9f41e7db-bc4b-46ea-bcf7-f08aa9786953.PNG)


Halaman Stock Barang (Gudang)
![Stock Barang](https://user-images.githubusercontent.com/45915194/158020017-e23266a6-8e5f-4bd7-b79e-4b9c8f69f61f.PNG)


Halaman Barang Masuk (Gudang)
![Barang Masuk](https://user-images.githubusercontent.com/45915194/158020019-5e5edc1e-c1c2-462e-8c20-29973a6d1200.PNG)


Halaman Barang Keluar(Gudang)
![Barang Keluar](https://user-images.githubusercontent.com/45915194/158020018-147ba738-0860-4e87-aab7-2ba8d5d6722d.PNG)


Halaman Permintaan Pembelian (Gudang)
![Permintaan Barang](https://user-images.githubusercontent.com/45915194/158020015-6069715d-4f52-45fc-960c-1f9688a9db4d.PNG)


Halaman Beranda (Purchasing)
![beranda](https://user-images.githubusercontent.com/45915194/158020154-64e783b1-4820-4bc1-8ea7-1a0bbc6871db.PNG)


Halaman Managemen Barang (Purchasing)
![managemen barang](https://user-images.githubusercontent.com/45915194/158020152-8663f6f6-98f1-4571-91f2-0c24d85e5ccc.PNG)


Halaman Purchasing Order (Purchasing)
![purchasing order](https://user-images.githubusercontent.com/45915194/158020153-7f1b87ab-3d83-41c4-9f0e-54bd7cbdf0e9.PNG)


Copyright (c) 2022, surevan08 https://github.com/surevan08
