</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Sistem Informasi Inventory Senja Kopi 2022 </span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/vendor/jquery/jquery.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/js/sb-admin-2.min.js'); ?>"></script>

<!-- Page level plugins -->
<script src="<?= base_url('assets/vendor/datatables/jquery.dataTables.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/dataTables.bootstrap4.min.js'); ?>"></script>

<!-- Custom DataTable  -->
<script src="<?= base_url('assets/vendor/datatables/Buttons-2.2.2/js/dataTables.buttons.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/Buttons-2.2.2/js/buttons.bootstrap4.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/JSZip-2.5.0/jszip.min.js'); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="<?= base_url('assets/vendor/datatables/pdfmake-0.1.36/vfs_fonts.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/Buttons-2.2.2/js/buttons.html5.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/Buttons-2.2.2/js/buttons.print.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/Buttons-2.2.2/js/buttons.colVis.min.js'); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?= base_url('assets/js/demo/datatables-demo.js'); ?>"></script>

<!--Daterangepicker -->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<!--DateRangePicker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<!-- 
<script>
    $(document).ready(function() {
        var table = $('#custom-table').DataTable({
            buttons: ['excel', 'pdf', 'print', 'colvis'],
            dom: "<'row'<'col-md-3'l><'col-md-5'B><'col-md-4'f>>" +
                "<'row'<'col-md-12'tr>>" +
                "<'row'<'col-md-5'i> <'col-md-7'p>>"
        });
        table.buttons().container()
            .appendTo('#custom-table_wrapper .col-md-5:eq(0)');
    });
</script> -->


</body>

</html>